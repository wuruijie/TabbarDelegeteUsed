//
//  AppDelegate.h
//  ZQAnimationTabBar
//
//  Created by lzq on 17/6/8.
//  Copyright © 2017年 lzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, assign)BOOL loadOK;

@end

