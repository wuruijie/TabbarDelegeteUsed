//
//  LoadViewController.m
//  ZQAnimationTabBar
//
//  Created by XinHuiOS on 2019/5/5.
//  Copyright © 2019 lzq. All rights reserved.
//

#import "LoadViewController.h"
#import "AppDelegate.h"
@interface LoadViewController ()

@end

@implementation LoadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor cyanColor];
    self.navigationItem.hidesBackButton =YES;
    self.navigationItem.title = @"点击item时候弹出登录";
    UIButton * b =[UIButton  buttonWithType:UIButtonTypeContactAdd];
    b.frame = CGRectMake(100,100,100,30);
    [self.view addSubview:b];
    [b addTarget:self action:@selector(load:) forControlEvents:UIControlEventTouchUpInside];
    
}
//登陆之后返回
-(void)load:(UIButton *)b  {
    AppDelegate * delegete =(AppDelegate *)[UIApplication sharedApplication].delegate;
    delegete.loadOK = YES;
    
    //发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"a" object:[NSString stringWithFormat:@"%zd",self.selectIndex]];
    
    [self.navigationController popViewControllerAnimated:YES];
}
//不登录直接返回
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

@end
